const Sequelize = require('sequelize');

// Initialize Sequelize with database credentials
const sequelize = new Sequelize('your_database_name', 'your_username', 'your_password', {
  host: 'localhost',
  dialect: 'mysql'
});

// Export sequelize object
module.exports = sequelize;