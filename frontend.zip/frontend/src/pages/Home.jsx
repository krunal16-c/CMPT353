import React from 'react'
import Banner from '@/components/home/Banner'
export default function Home () {
  return (
    <>
      <Banner />
    </>
  )
}
