import React from 'react'

export default function postData ({ data }) {
  return <p className='text-sm'>{data}</p>
}
